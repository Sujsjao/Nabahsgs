const { Client, Message, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const profile = require('../../models/profile');
const BaseCommand = require('../../utils/structures/BaseCommand');

module.exports = class CreateCommand extends BaseCommand {
  constructor() {
    super('انشاء', 'jails', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
   
  if(message.channel.id != "1111649824765394974") return
      if(!message.member?.roles.cache.has("1112784425638436900") &&  message.author.id != "1031853134554877992") return
    let m = message.mentions.members?.first()
    if(!m) return message.reply({content :":x: | منشن عضو"})
    let row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
      .setStyle(ButtonStyle.Primary)
      .setLabel("استبيان")
      .setCustomId(`modal_${m.id}_${message.member?.id}`)
    )
    message.reply({
      content : "يرجى تعبئة الاستبيان من الاسفل بالضغط على الزر الازرق",
      components : [row]
    })
    }
}