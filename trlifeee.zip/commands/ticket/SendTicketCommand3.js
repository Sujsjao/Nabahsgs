// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('فني', 'ticket', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open3')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تذكرة - مساعدة`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("قسم المساعدة")
      .setDescription(`** <:pp449:1069609005804175472> - طلب مساعده

<:pp407:1069609064545402880> - مرحبآ بك عزيزي العضو في سيرفر  تي ار لايف لطلب مساعده قم بفتح تكت    
<:pp186:1069609208326127686> - ملاحظة
      
1 - يرجى عدم فتح تكت بدون سبب
      
2 -  يرجى منك كتابه ما تريد
      
3 - بعد كتابه ماتريد انتضر الرد من قبل الادارة بدون ازعاج
      
<:pp521:1069608739885285407> - إدارة تي ار لايف تحت خدمتكم**`)
.setImage("")

    message.channel.send({
      embeds: [embed],
      components: [button]
    })
  }
}