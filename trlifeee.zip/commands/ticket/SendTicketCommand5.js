// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('sendTicket5', 'ticket', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open5')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تذكرة - عضويات`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("قسم العضويات")
      .setDescription(`** <:pp449:1069609005804175472> - طلب عضوية

<:pp407:1069609064545402880> - مرحبآ بك عزيزي العضو فـي سيرفر وندر ستي لطلب عضوية قم بفتح تذكره    
      
<:pp186:1069609208326127686> - ملاحظة
      
1 - يرجى اختيار العضوية 
      
2 - بعد اختيار العضوية قم ب انتضار الاداره بدون ازعاج 
      
<:pp521:1069608739885285407> - إدارة وندر ستي تحت خدمتكم**`)
//.setImage("https://cdn.discordapp.com/attachments/1078742446038589531/1079444690270695444/1677279398322.jpg")

    message.channel.send({
      embeds: [embed],
      components: [button]
    })
  }
}