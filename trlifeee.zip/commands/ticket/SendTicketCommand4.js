// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('sendTicket4', 'ticket', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open4')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تذكرة - شكوى`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("قسم الشكاوي")
      .setDescription(`** <:pp449:1069609005804175472> - رفع شكوى

<:pp407:1069609064545402880> - مرحبآ بك عزيزي العضو في سيرفر  تي ار لايف لرفع شكوى قم بفتح تكت     
      
<:pp186:1069609208326127686> - ملاحظة
      
1 - يرجى عدم فتح تذكره على اسباب تافهه 
      
2 - يرجى تعبئه الاستبيان كامل 
      
3 - بعد تعبئه الاستبيان انتضر الرد من قبل الادارة بدون ازعاج  
      
<:pp521:1069608739885285407> - ادارة سيرفر تحت خدمتكم **`)
.setImage("")

    message.channel.send({
      embeds: [embed],
      components: [button]
    })
  }
}