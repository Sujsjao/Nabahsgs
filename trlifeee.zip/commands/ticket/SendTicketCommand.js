// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('تفعيل1', 'ticket', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تذكرة - تفعيل`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("قسم التفعيل")
      .setDescription(`** > - تكت التفعيل

- مرحبآ بك عزيزي العضو في سيرفر   تي ار لايف لكي تتفعل قم بفتح تكت    
      
- ملاحظة
      
1 - يرجى تعبئه الاستبيان كامل 
      
2 - بعد تعبئه الاستبيان يرجى منك التوجه ل روم لـ قول القسم
      
3 - اذا تم تفعيلك يرجى الالتزام ب القوانين كامله

 - متمنين لكم اوقات ممتعه في  تي ار لايف**`)
    message.channel.send({embeds: [embed] , components: [button]})
  }
}