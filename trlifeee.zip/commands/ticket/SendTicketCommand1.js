// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('اعلان', 'ticket', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open1')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تذكرة - شكاوي`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("قسم-الشكاوي")
      .setDescription(`لفتح تذكره يرجى ما عليك ضغظ الذي اسفل 
      
      1- عدم استهبال
      
      2- يرجى كتب مشكلتك و دلايل
      
      3- يجب ان يكون معك دليل
      
 تي ار لايف لخدمتكم **`)
//.setImage("https://cdn.discordapp.com/attachments/1078742446038589531/1079444690270695444/1677279398322.jpg")

    message.channel.send({
      embeds: [embed],
      components: [button]
    })
  }
}