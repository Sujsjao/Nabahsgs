const BaseEvent = require('../../utils/structures/BaseEvent');

module.exports = class MessageEvent extends BaseEvent {
  constructor() {
    super('messageCreate');
  }
  
  async run(client, message) {
    if(message.content == "خط"){
      if(!message.member.roles.cache.has("1110884593130819674") && message.author.id != client.user.id) return
      message.delete()
      message.channel.send({content : "https://cdn.discordapp.com/attachments/1115642218418544781/1116821779315425341/935509159581982720.gif"})
      return
  }
    if (message.author.bot) return;

  
  }
}