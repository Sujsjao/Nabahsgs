const BaseEvent = require('../../utils/structures/BaseEvent');

module.exports = class MessageEvent extends BaseEvent {
  constructor() {
    super('messageCreate');
  }

  async run(client, message) {
    if (message.content.includes("مين أفضل مبرمجين؟") || message.content.includes("مين افضل مبرمجين؟")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**<@227889974689660929> x <@489501373499572224>**");
    } else if (message.content.includes("مين أفضل موسسين؟") || message.content.includes("مين افضل موسسين؟")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**<@941710416076234814> x <@871781195766181929> x <@838760535477714975>**");
    } else if (message.content.includes("مين أفضل نائب؟") || message.content.includes("مين افضل نائب؟")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**<@1022477249552850954>**");
    } else if (message.content.includes("مين عم ابو حسوني؟") || message.content.includes("مين عم ابو حسوني؟")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**<@227889974689660929> صقر اكيد يعني**");
    } else if (message.content.includes("مين أفضل عضو مجلس؟") || message.content.includes("مين افضل عضو مجلس؟")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**<@1008074786276122726>**");
    } else if (message.content.includes("مين أفضل سيرفر رول بلاي؟") || message.content.includes("مين افضل سيرفر رول بلاي؟")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**افضل سيرفر بدون سؤال هوا وندر بالتاكيد🤨**");
    } else if (message.content.includes("8888888") || message.content.includes("8888888")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**  **");
    } else if (message.content.includes("8888888") || message.content.includes("8888888")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**  **");
    } else if (message.content.includes("8888888") || message.content.includes("8888888")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**  **");
    } else if (message.content.includes("8888888") || message.content.includes("8888888")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**  **");
    } else if (message.content.includes("8888888") || message.content.includes("8888888")) {
      if (!message.member.roles.cache.has("987310271087394857") && message.author.id !== client.user.id) return;
      message.reply("**  **");
    }
  }
};
