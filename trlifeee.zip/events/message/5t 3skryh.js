const BaseEvent = require('../../utils/structures/BaseEvent');

module.exports = class MessageEvent extends BaseEvent {
  constructor() {
    super('messageCreate');
  }
  
  async run(client, message) {
    if(message.content == "خط الداخلية"){
      if(!message.member.roles.cache.has("1110884678241636352") && message.author.id != client.user.id) return
      message.delete()
      message.channel.send({content : "https://cdn.discordapp.com/attachments/1110883078987055124/1117100243427795016/IMG_0590.png"})
      return
  }
    
  }
}