const BaseEvent = require('../../utils/structures/BaseEvent');

module.exports = class MessageEvent extends BaseEvent {
  constructor() {
    super('messageCreate');
  }
  
  async run(client, message) {
    if(message.content == "خط العصابة"){
      if(!message.member.roles.cache.has("1110884730259374153") && message.author.id != client.user.id) return
      message.delete()
      message.channel.send({content : "https://cdn.discordapp.com/attachments/1110883078987055124/1117100435052965888/Picsart_23-06-08_20-51-54-750.jpg"})
      return
  }
    
  }
}