// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('sendTicket6', 'ticket', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender) && message.author.id != "1112784425638436900") return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open6')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تذكرة - تقديم`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("قسم التقديم")
      .setDescription(`** <:pp449:1069609005804175472> - تكت تقديم إدارة

<:pp407:1069609064545402880> - مرحبآ بك عزيزي العضو في سيرفر وندر ستي للتقديم على إدارة وندر ستي قم بفتح تكت
      
<:pp186:1069609208326127686> - ملاحظة
      
1 - يرجى تعبئه الاستبيان كامل 
      
2 - اذا تم قبولك يرجى التوجه لـ روم القسم 
      
3 - اذا تم قبولك يرجى الالتزام ب القوانين كامله

<:pp521:1069608739885285407> - متمنين لكم اوقات ممتعه في WONDER CITY**`)
//.setImage("https://cdn.discordapp.com/attachments/1078742446038589531/1079444690270695444/1677279398322.jpg")

    message.channel.send({
      embeds: [embed],
      components: [button]
    })
  }
}