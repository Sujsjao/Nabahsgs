const { Client, Message, EmbedBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const points = require('../../models/points');

module.exports = class KhasemCommand extends BaseCommand {
  constructor() {
    super('خصم', 'eco', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if(message.author.id != "1031853134554877992") return
    let member = message.mentions.members?.first()
    if(!member) return
    await points.deleteOne({user : member.id})
    message.reply({content : "✅ | تم تصفير العضو بنجاح"})
    client.channels.cache.get("1117120961397919784").send({
      embeds : [
        new EmbedBuilder()
        .setColor("Random")
        .setTimestamp()
        .setFooter({iconURL : client.user?.displayAvatarURL(),text : client.user?.username})
        .setDescription(`
تم تصفير نقاط

الإداري : ${member}
        
السبب : تصفير من اونر
`)
      ]
    })
  }
}