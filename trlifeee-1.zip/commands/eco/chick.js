const { Client, Message } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const bank = require("../../models/bank")
let {ch}= require("../../config")
module.exports = class AddCommand extends BaseCommand {
  constructor() {
    super('زيادة', 'eco', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
      
  if(message.channel.id != "1110883090529796156" && message.author.id != "1031853134554877992") return

      if(!message.member.roles.cache.has(ch) && message.author.id != "1116685498493177856") return
    if(!args[1] || !message.mentions.members?.first()) return message.reply({content : " @منشن المبلغ"})
    let data = await bank.findOne({user:message.mentions.role.first()?.id})
    data.bank += parseInt(args[1])
    await data.save()
    message.reply({content : "✅ | تمت اضافة المبلغ بنجاح"})
      message.guild?.channels.cache.find(x=>x.id == "1117120961397919784").send({
          content : `
تمت اضافة مبلغ ${args[1]}
للعضو : ${message.mentions.members.first()}
بواسطة الادمن : ${message.member}
باستخدام امر شيك `
        })
  }
}