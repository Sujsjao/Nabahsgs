const { ActionRowBuilder, StringSelectMenuBuilder } = require('@discordjs/builders');
const { Client, Message, SelectMenuOptionBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand'); let rolesDb = [
 ["1149306887800619058","1148922372586483833","1148908194115112960","1148931617746853898"],

["1146836534130131065","1148931617746853898","1148922372586483833","11489081941151129601149633408155267104"],

["1144211552749244507","1144211167665991761","",""],

["1143602907833442404","1143278886147346603","",""],

["1148237446463619132","","",""],

["1145139832788631552","","",""],

["1143152106543526009","1143151873067585627","",""],

["1143151237743788153","1143150994956501134","",""],

["1145092241262641202","","",""],

["1143151965040287864","1143151873067585627","",""],

] 
module.exports = class AcceptCommand extends BaseCommand {
  constructor() {
    super('تعاقد', 'roles', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if(!message.member?.roles.cache.has("1149633408155267104")) return message.reply({content:"لاتملك صلاحية استخدام هذا الامر"})
    let ob =[
      {
        name : "الامن العام",
        id :"0"
      
     },
    {
        name : "القوات الخاصة",
        id :"1"
      },{
          name : "قريبا",
          id : "2"
      }
    ]
    let ob2 = [{
      name : "بلود",
      id : "4"
    },{
      name : "كوزا",
      id : "5"
    },{
      name : "قريبا",
      id : "5"
    }]
    let ob3 = [{
      name : "قريبا",
      id: "6"
    },{
      name :"محامي",
      id : "8"
    },{
      name : "قريبا",
      id : "9"
      },{   
      name : "قريبا",
      id : "10"
    }]
    if(!message.mentions.members?.first()) return message.reply({content : "الرجاء منشن عضو"})
    let s = new StringSelectMenuBuilder()
    .setCustomId("kia3at")
    .setMaxValues(1)
    .setPlaceholder("القطاعات الحكومية")
    ob.forEach(x=>{
      s.addOptions([new SelectMenuOptionBuilder().setLabel(x.name).setValue(x.id)])
    })
    let s2 = new StringSelectMenuBuilder()
    .setCustomId("esabat")
    .setMaxValues(1)
    .setPlaceholder("العصابات")
    ob2.forEach(x=>{
      s2.addOptions([new SelectMenuOptionBuilder().setLabel(x.name).setValue(x.id)])
    })
    let s3 =   new StringSelectMenuBuilder()
    .setCustomId("other")
    .setMaxValues(1)
    .setPlaceholder("وظائف اخرى")
    ob3.forEach(x=>{
      s3.addOptions([new SelectMenuOptionBuilder().setLabel(x.name).setValue(x.id)])
    })
    let rowq = new ActionRowBuilder()
    .addComponents(
      s
    )
    let rowq2 = new ActionRowBuilder()
    .addComponents(
      s2
    )
    let rowq3 = new ActionRowBuilder()
    .addComponents(
      s3
    )
   let dk = await  message.reply({components :[rowq,rowq2,rowq3]})
    const filter = (interaction) => interaction.user.id == message.author.id;

    let collected = await dk.awaitMessageComponent({ filter, time: 15_000}).catch((c) =>{
        console.log(`After five seconds, ${c.size} messages are collected.`)
        message.channel.send(":x: | تم الغاء الامر لعدم التفاعل")
    });
      if(!collected) return
    rolesDb[Number(collected.values[0])].forEach(k=>{
      message.mentions.members.first()?.roles.remove(k).catch(null)
    })
    collected.reply({content : `
تم سحب رتب | ${message.mentions.members.first()}

في وظيفة | ${collected.component.options.find(x=> x.value == collected.values[0]).label}

المسؤول عن القبول | ${message.member}`})
    let ob77 = ob.concat(ob2,ob3)
    
    client.channels.cache.get("1117120961397919784").send({
      content : `
تم سحب رتب العضو : ${message.mentions.members.first()}
بواسطة الادمن : ${message.member}
كـ : ${ob77.find(k=>k.id == collected.values[0])?.name}
`
    })
    }
}